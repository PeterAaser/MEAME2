﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Mcs.Usb;

namespace StgDownloadExampleNet
{
    public partial class Form1 : Form
    {
        private CMcsUsbListNet usblist = new CMcsUsbListNet();
        private CStg200xDownloadNet device = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void bt_StgDevice_present_Click(object sender, EventArgs e)
        {
            cbDevices.Items.Clear();
            usblist.Initialize(DeviceEnumNet.MCS_STG_DEVICE);
            for (uint i = 0; i < usblist.Count; i++)
            {
                cbDevices.Items.Add(usblist.GetUsbListEntry(i).DeviceName + " / " + usblist.GetUsbListEntry(i).SerialNumber);
            }
            if (cbDevices.Items.Count > 0)
            {
                cbDevices.SelectedIndex = 0;
                btConnect.Enabled = true;
            }
        }

        private void btConnect_Click(object sender, EventArgs e)
        {
            if (device != null)
            {
                device.SendStop(1);
                device.Disconnect();
                device.Dispose();
                device = null;
            }

            device = new CStg200xDownloadNet(pollHandler);
            device.Connect(usblist.GetUsbListEntry((uint)cbDevices.SelectedIndex));

            cbDevices.Enabled = false;
            btConnect.Enabled = false;
            btStart.Enabled = true;
            btStop.Enabled = false;
            btDisconnect.Enabled = true;
        }

        private void btDisconnect_Click(object sender, EventArgs e)
        {
            device.SendStop(1);
            device.Disconnect();
            device.Dispose();
            device = null;

            cbDevices.Enabled = true;
            btConnect.Enabled = true;
            btStart.Enabled = false;
            btStop.Enabled = false;
            btDisconnect.Enabled = false;
        }
       
        private void btStart_Click(object sender, EventArgs e)
        {
            int DACResolution = device.GetDACResolution();

            device.SetCurrentMode();
            device.GetCurrentRangeInNanoAmp(0);
            device.GetCurrentResolutionInNanoAmp(0);

            SetupMemory(); // Not necessary if default is sufficient

            // Setup Trigger
            uint TriggerInputs = device.GetNumberOfTriggerInputs();
            uint[] channelmap = new uint[TriggerInputs];
            uint[] syncoutmap = new uint[TriggerInputs];
            uint[] repeat = new uint[TriggerInputs];
            for (int i = 0; i < TriggerInputs; i++)
            {
                channelmap[i] = 0;
                syncoutmap[i] = 0;
                repeat[i] = 0;
            }
            // Trigger 0
            channelmap[0] = 1; // Channel 1
            syncoutmap[0] = 1; // Syncout 1
            repeat[0] = 0; // forever

            // Trigger 1
            channelmap[1] = 4; // Channel 3 

            device.SetupTrigger(0, channelmap, syncoutmap, repeat);

            // Data for Channel 0
            {
                device.ClearChannelData(0);

                double factor = 1;

                const int l = 1000;
                // without compression
                ushort[] pData = new ushort[l];
                UInt64[] tData = new UInt64[l];
                for (int i = 0; i < l; i++)
                {
                    // calculate Sin-Wave
                    double sin = factor * (Math.Pow(2, DACResolution - 1) - 1.0) * 
                        Math.Sin(2.0 * (double)i * Math.PI / (double)l);

                    // calculate sign
                    pData[i] = sin >= 0 ? (ushort)sin : (ushort)((int)Math.Abs(sin) + 
                        (int)Math.Pow(2, DACResolution - 1));

                    tData[i] = (UInt64)20; // duration in µs
                }
                device.SendChannelData(0, pData, tData);
                /*
                // with compression
                List<ushort> pData = new List<ushort>();
                List<UInt64> tData = new List<UInt64>();
                int j = 0;
                for (int i = 0; i < l; i++)
                {
                    // calculate Sin-Wave
                    double sin = factor * (Math.Pow(2, DACResolution - 1) - 1.0) * 
                        Math.Sin(2.0 * (double)i * Math.PI / (double)l);

                    // calculate sign
                    ushort newval = sin >= 0 ? (ushort)sin : (ushort)((int)Math.Abs(sin) + 
                        (int)Math.Pow(2, DACResolution - 1));

                    // do compression, duration in µs
                    if (j > 0 && pData[j - 1] == newval)
                    {
                        tData[j - 1] += 20;
                    }
                    else
                    {
                        pData.Add(newval);
                        tData.Add(20);
                        j++;
                    }
                }
                device.SendChannelData(0, pData.ToArray(), tData.ToArray());
                */
            }

            // Data for Channel 3
            {
                device.ClearChannelData(2);

                double factor = 0.1;

                const int l = 700;
                // without compression
                ushort[] pData = new ushort[l];
                UInt64[] tData = new UInt64[l];
                for (int i = 0; i < l; i++)
                {
                    // calculate Sin-Wave
                    double sin = factor * (Math.Pow(2, DACResolution - 1) - 1.0) * 
                        Math.Sin(2.0 * (double)i * Math.PI / (double)l);

                    // calculate sign
                    pData[i] = sin >= 0 ? (ushort)sin : (ushort)((int)Math.Abs(sin) + 
                        (int)Math.Pow(2, DACResolution - 1));

                    tData[i] = (UInt64)20; // duration in µs
                }
                device.SendChannelData(2, pData, tData);
            }
            // Data for Sync 0
            {
                device.ClearSyncData(0);
                
                ushort[] pData = new ushort[1000];
                UInt64[] tData = new UInt64[1000];
                for (int i = 0; i < 1000; i++)
                {
                    pData[i] = (ushort)(i & 1);
                    tData[i] = 20; // duration in µs
                }
                device.SendSyncData(0, pData, tData);
            }

            // Only meaningfull for STG400x
            device.SetVoltageMode();

            // Start Trigger 1 and 2
            device.SendStart(1 + 2); // Trigger 1 and 2

            btStart.Enabled = false;
            btStop.Enabled = true;
        }

        private void btStop_Click(object sender, EventArgs e)
        {
            device.SendStop(1 + 2); // Trigger 1 and 2

            btStart.Enabled = true;
            btStop.Enabled = false;
        }

        void pollHandler(uint status, int[] index_list)
        {
            if (InvokeRequired)// in the context of the poll thread 
            {
                // Change Context
                Invoke(new OnStg200xPollStatus(pollHandler), new Object[] { status, index_list });
            }
            else // in the context of the GUI
            {
                tbPollValue.Text = status.ToString("X8");
            }
        }

        void SetupMemory()
        {
            uint memory = device.GetTotalMemory();  // obtain total memory available
            
            uint[] segmentmemory = new uint[2];     // each segments has half of total memory
            segmentmemory[0] = memory / 2;
            segmentmemory[1] = memory / 2;
            device.SendSegmentDefine(segmentmemory);// setup the STG

            uint nchannels = device.GetNumberOfAnalogChannels();
            uint nsync = device.GetNumberOfSyncoutChannels();
            uint[] channel_cap = new uint[nchannels];
            uint[] syncout_cap = new uint[nsync];
            for (int i = 0; i < 2; i++)                             // for each segment
            {
                device.SendSegmentSelect((uint)i, 0);                  // switch to segment
                uint segment_mem = device.GetMemory();              // get memory available in this segment

                for (int j = 0; j < nchannels; j++)
                {
                    channel_cap[j] = segment_mem / (nchannels + nsync); // devide memory amount to all channels
                }
                for (int j = 0; j < nsync; j++)
                {
                    syncout_cap[j] = segment_mem / (nchannels + nsync); // and all sync outs.
                }

                device.SetCapacity(channel_cap, syncout_cap);       // define memory for current segment
            }

            device.SendSegmentSelect(0, 0);
        }
    }
}
