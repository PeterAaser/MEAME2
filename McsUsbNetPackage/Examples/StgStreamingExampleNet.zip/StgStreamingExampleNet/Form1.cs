﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Form1.cs" company="Multi Channel Systems MCS GmbH">
//   
// </copyright>
// <summary>
//   Defines the Form1 type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

#define pollfordata

namespace StgStreamingExampleNet
{
    using System;
    using System.Globalization;
    using System.Windows.Forms;

    using Mcs.Usb;

    public partial class Form1 : Form
    {
        private const int Channels = 8;
        private readonly CMcsUsbListNet usblist = new CMcsUsbListNet();
        private CStg200xStreamingNet device;

        private const double Factor = 1;

#if pollfordata
        private readonly Timer timer = new Timer();
#endif
        public Form1()
        {
            InitializeComponent();
            BtStgDevicePresentClick(null, null);
#if pollfordata
            timer.Tick += new EventHandler(TimerTick);
            timer.Interval = 20;
#endif
        }

#if !pollfordata
        private static void ErrorHandler()
        {
        }
#endif

        private void BtStgDevicePresentClick(object sender, EventArgs e)
        {
            cbDevices.Items.Clear();
            usblist.Initialize(DeviceEnumNet.MCS_STG_DEVICE);
            for (uint i = 0; i < usblist.Count; i++)
            {
                cbDevices.Items.Add(usblist.GetUsbListEntry(i).DeviceName + " / " + usblist.GetUsbListEntry(i).SerialNumber);
            }
            if (cbDevices.Items.Count > 0)
            {
                cbDevices.SelectedIndex = 0;
            }
        }

        private void CbDevicesSelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void BtStartClick(object sender, EventArgs e)
        {
            if (device != null)
            {
                device.SendStop(1);
                device.Dispose();
                device = null;
            }

#if pollfordata
            device = new CStg200xStreamingNet(50000);
#else
            device = new CStg200xStreamingNet(50000, DataHandler, ErrorHandler);
#endif
            device.Connect(usblist.GetUsbListEntry((uint)cbDevices.SelectedIndex));
            device.EnableContinousMode();
            device.SetOutputRate(50000);

            SetupMemory(); // Not necessary if default settings is sufficient

            uint ntrigger = device.GetNumberOfTriggerInputs();  // obtain number of triggers in this STG
            uint[] channelmap = new uint[ntrigger];
            uint[] syncoutmap = new uint[ntrigger];
            uint[] digoutmap = new uint[ntrigger];
            uint[] autostart = new uint[ntrigger];
            uint[] callbackThreshold = new uint[ntrigger];
            for (int i = 0; i < ntrigger; i++)
            {
                channelmap[i] = 0;
                syncoutmap[i] = 0;
                digoutmap[i] = 0;
                autostart[i] = 0;
                callbackThreshold[i] = 0;
            }

            for (int channel = 0; channel < Channels; channel++)
            {
                channelmap[0] |= (uint)1 << channel; // assign all channels to trigger 1
            }
            syncoutmap[0] = 0;   // No Syncout
            autostart[0] = 0;
            callbackThreshold[0] = 50; // 50% of buffer size

            device.SetupTrigger(channelmap, syncoutmap, digoutmap, autostart, callbackThreshold);

            // Only meaningfull for STG400x
            device.SetVoltageMode();

            device.StartLoop();
            System.Threading.Thread.Sleep(1000); // Give StartLoop some time
            device.SendStart(1);

            timer1.Enabled = true;
#if pollfordata
            timer.Enabled = true;
#endif

        }

        private void BtStopClick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
#if pollfordata
            timer.Enabled = false;
#endif


            device.SendStop(1);
            device.StopLoop();
        }

        private void SetupMemory()
        {
            uint dwMemory = device.GetTotalMemory();            // obtain total memory available

            uint ntrigger = device.GetNumberOfTriggerInputs();  // obtain number of triggers in this STG

            /*
            uint[] stg_triggercapacity = new uint[ntrigger];
            for (int i = 0; i < ntrigger; i++)
                stg_triggercapacity[i] = dwMemory / ntrigger;
            */

            uint[] stgTriggercapacity = new uint[ntrigger];
            for (int i = 0; i < ntrigger; i++)
            {
                stgTriggercapacity[i] = 50000;
            }
            device.SetCapacity(stgTriggercapacity);            // setup the STG
        }


#if pollfordata
        private void TimerTick(object sender, EventArgs e)
        {
            SendStreamingData();
        }
#else
        private void DataHandler(uint trigger)
        {
            if (trigger == 0) // Callback for Trigger 1
            {
                SendStreamingData();
            }
        }
#endif

        private void SendStreamingData()
        {
            for (uint channel = 0; channel < Channels; channel++)
            {
                uint space = device.GetDataQueueSpace(channel);

                for (int periods = 0; periods < space / 1000; periods++)
                {
                    short[] data = new short[1000];
                    for (int i = 0; i < 1000; i++)
                    {
                        // Calc Sin-Wave (16 bits) lower bits will be removed according resolution
                        double sin = Factor * (Math.Pow(2, 16 - 1) - 1.0) * Math.Sin(2.0 * i * Math.PI / 1000 * (channel + 1));
                        data[i] = (short)sin;
                    }
                    device.EnqueueData(channel, data);
                }
            }
        }

        private void Timer1Tick(object sender, EventArgs e)
        {
            tbBytesBuffered.Text = device.GetFramesBuffered(0).ToString(CultureInfo.InvariantCulture);
            tbCurrentRate.Text = (8.0 * device.GetCurrentRate(0) / (1 << 14)).ToString(CultureInfo.InvariantCulture);
            tbRateRaw.Text = device.GetCurrentRate(0).ToString(CultureInfo.InvariantCulture);
        }
    }
}
