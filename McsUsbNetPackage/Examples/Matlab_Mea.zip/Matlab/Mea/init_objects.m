assembly = NET.addAssembly([pwd '\McsUsbNet.dll']);
device = Mcs.Usb.CMeaUSBDeviceNet();
%device = Mcs.Usb.CMC_CardDeviceNet();
